import type {
  ChannelAdapter,
  ChannelConfiguration,
  NormalizedCustomerMessage,
  ChannelResponse,
} from "./types";

export const webChannel: ChannelAdapter = {
  type: "web",

  async receive(
    request: Request,
    configuration: ChannelConfiguration
  ): Promise<NormalizedCustomerMessage[]> {

    const body =
      await request.json().catch(
        () => ({})
      ) as any;

    if (
      typeof body.text !== "string" ||
      !body.text.trim()
    ) {
      return [];
    }

    return [
      {
        channel: "web",

        tenantId:
          configuration.tenant_id,

        projectId:
          configuration.project_id,

        serviceId:
          configuration.service_id ||
          undefined,

        externalUserId:
          typeof body.user_id === "string"
            ? body.user_id
            : "anonymous",

        externalConversationId:
          typeof body.conversation_id === "string"
            ? body.conversation_id
            : undefined,

        externalMessageId:
          typeof body.message_id === "string"
            ? body.message_id
            : undefined,

        text:
          body.text.trim(),

        metadata:
          body.metadata &&
          typeof body.metadata === "object"
            ? body.metadata
            : undefined,

        timestamp:
          Date.now(),
      },
    ];
  },

  async send(
    _response: ChannelResponse,
    _message: NormalizedCustomerMessage,
    _configuration: ChannelConfiguration,
    _env: any
  ) {
    /*
     * Web Chat is synchronous.
     *
     * The HTTP route returns the response
     * directly to the browser.
     */
  },
};