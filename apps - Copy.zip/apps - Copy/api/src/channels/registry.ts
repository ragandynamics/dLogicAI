import type {
  ChannelAdapter,
  ChannelType,
} from "./types";

const adapters =
  new Map<ChannelType, ChannelAdapter>();

export function registerChannel(
  adapter: ChannelAdapter
) {
  adapters.set(
    adapter.type,
    adapter
  );
}

export function getChannel(
  type: ChannelType
) {
  return adapters.get(type);
}

export function listChannels() {
  return [
    ...adapters.keys(),
  ];
}