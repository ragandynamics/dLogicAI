import type {
  ChannelAdapter,
  ChannelConfiguration,
  NormalizedCustomerMessage,
  ChannelResponse,
} from "./types";

type WhatsAppConfiguration = {
  access_token: string;
  phone_number_id: string;
  verify_token?: string;
};

export const whatsappChannel: ChannelAdapter = {
  type: "whatsapp",

  async receive(
    request: Request,
    configuration: ChannelConfiguration
  ): Promise<NormalizedCustomerMessage[]> {

    /*
     * WhatsApp credentials/configuration are
     * decrypted by the route before calling this
     * adapter.
     *
     * The webhook payload itself does not contain
     * the tenant/project identity.
     */

    const body =
      await request.json().catch(
        () => ({})
      ) as any;

    const messages: NormalizedCustomerMessage[] = [];

    const entries =
      Array.isArray(body?.entry)
        ? body.entry
        : [];

    for (const entry of entries) {

      const changes =
        Array.isArray(entry?.changes)
          ? entry.changes
          : [];

      for (const change of changes) {

        const value =
          change?.value;

        const incoming =
          Array.isArray(
            value?.messages
          )
            ? value.messages
            : [];

        for (const message of incoming) {

          if (
            message?.type !== "text"
          ) {
            continue;
          }

          const text =
            message?.text?.body;

          if (
            typeof text !== "string" ||
            !text.trim()
          ) {
            continue;
          }

          messages.push({
            channel: "whatsapp",

            tenantId:
              configuration.tenant_id,

            projectId:
              configuration.project_id,

            serviceId:
              configuration.service_id ||
              undefined,

            externalUserId:
              String(
                message.from
              ),

            externalConversationId:
              String(
                message.from
              ),

            externalMessageId:
              message.id
                ? String(message.id)
                : undefined,

            text:
              text.trim(),

            metadata: {
              whatsapp_message_type:
                message.type,
            },

            timestamp:
              Date.now(),
          });
        }
      }
    }

    return messages;
  },

  async send(
    response: ChannelResponse,
    message: NormalizedCustomerMessage,
    configuration: ChannelConfiguration,
    env: any
  ) {

    if (
      !configuration
        .configuration_encrypted
    ) {
      throw new Error(
        "WhatsApp configuration is missing."
      );
    }

    const config =
      JSON.parse(
        await env.decryptChannelConfiguration(
          configuration
            .configuration_encrypted
        )
      ) as WhatsAppConfiguration;

    const responseUrl =
      `https://graph.facebook.com/v23.0/` +
      `${config.phone_number_id}/messages`;

    const result =
      await fetch(
        responseUrl,
        {
          method: "POST",

          headers: {
            Authorization:
              `Bearer ${config.access_token}`,

            "Content-Type":
              "application/json",
          },

          body: JSON.stringify({
            messaging_product:
              "whatsapp",

            to:
              message.externalUserId,

            type:
              "text",

            text: {
              body:
                response.text,
            },
          }),
        }
      );

    if (!result.ok) {

      const error =
        await result.text();

      throw new Error(
        `WhatsApp API error ${result.status}: ${error}`
      );
    }
  },
};