export type ChannelType =
  | "web"
  | "whatsapp"
  | "facebook"
  | "instagram"
  | "telegram"
  | "tiktok";

export type NormalizedCustomerMessage = {
  channel: ChannelType;

  tenantId: string;
  projectId: string;

  serviceId?: string;

  externalUserId: string;
  externalConversationId?: string;
  externalMessageId?: string;

  text: string;

  metadata?: Record<string, unknown>;

  timestamp: number;
};

export type ChannelConfiguration = {
  id: string;

  tenant_id: string;
  project_id: string;

  channel: ChannelType;

  name: string;

  enabled: number;

  service_id: string | null;

  public_key_prefix: string | null;
  public_key_hash: string | null;

  configuration_encrypted: string | null;

  created_at: number;
  updated_at: number;
};

export type ChannelResponse = {
  text: string;

  conversationId: string;

  requestId: string;

  model: string;

  provider: string;

  billingMode: string;

  language: {
    input: string;
    output: string;
    locale: string | null;
  };

  usage: {
    input_tokens: number;
    output_tokens: number;
    total_tokens: number;
  };
};

export interface ChannelAdapter {
  readonly type: ChannelType;

  receive(
    request: Request,
    configuration: ChannelConfiguration
  ): Promise<NormalizedCustomerMessage[]>;

  send(
    response: ChannelResponse,
    message: NormalizedCustomerMessage,
    configuration: ChannelConfiguration,
    env: any
  ): Promise<void>;
}