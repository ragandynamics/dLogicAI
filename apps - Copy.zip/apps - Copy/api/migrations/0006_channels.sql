-- dLogicAI customer channel configuration
--
-- A channel belongs to a project.
-- Channel credentials are encrypted by the API.
-- Public channel keys are stored as hashes.

CREATE TABLE IF NOT EXISTS channel_configurations (
  id TEXT PRIMARY KEY,

  tenant_id TEXT NOT NULL,
  project_id TEXT NOT NULL,

  channel TEXT NOT NULL,

  name TEXT NOT NULL,

  enabled INTEGER NOT NULL DEFAULT 1,

  service_id TEXT,

  public_key_prefix TEXT,
  public_key_hash TEXT,

  configuration_encrypted TEXT,

  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,

  FOREIGN KEY (tenant_id)
    REFERENCES tenants(id)
    ON DELETE CASCADE,

  FOREIGN KEY (project_id)
    REFERENCES projects(id)
    ON DELETE CASCADE,

  UNIQUE(project_id, channel)
);

CREATE INDEX IF NOT EXISTS
idx_channel_configurations_tenant
ON channel_configurations(tenant_id);

CREATE INDEX IF NOT EXISTS
idx_channel_configurations_project
ON channel_configurations(project_id);

CREATE INDEX IF NOT EXISTS
idx_channel_configurations_channel
ON channel_configurations(channel);

CREATE INDEX IF NOT EXISTS
idx_channel_configurations_public_key
ON channel_configurations(public_key_hash);